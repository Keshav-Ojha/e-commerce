create view role_column_grants
            (grantor, grantee, table_catalog, table_schema, table_name, column_name, privilege_type, is_grantable) as
SELECT grantor,
       grantee,
       table_catalog,
       table_schema,
       table_name,
       column_name,
       privilege_type,
       is_grantable
FROM information_schema.column_privileges
WHERE (grantor::name IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles))
   OR (grantee::name IN (SELECT enabled_roles.role_name
                         FROM information_schema.enabled_roles));

alter table role_column_grants
    owner to keshav;

grant select on role_column_grants to public;

